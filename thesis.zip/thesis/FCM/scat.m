% Scat(c) = (1/c * sum||var(vi)||) / ||var(vi)||
% ----------------------------------------------

function Scat = scat(X,c,V,U)

x_mean = mean(X,1);
n = size(X,1);
p = size(X,2);
var_X = zeros(p,1);
sum_var_V = 0;

for i=1:p,
    sum_X = 0;
    for j=1:n,
        X_tmp = X(j,i) - x_mean(1,i);
        sum_X = sum_X + (X_tmp^2);
    end
    var_X(i,1) = (1/n) * sum_X;
end

for k=1:c,
    var_V = zeros(p,1);
    for i=1:p,
        sum_V = 0;
        for j=1:n,            
            Y_tmp = X(j,i) - V(k,i);
            sum_V = sum_V + (U(k,j) * (Y_tmp^2));
        end
        var_V(i,1) = (1/n) * sum_V;
    end
    sum_var_V = sum_var_V + norm(var_V);
end

Scat = ((1/c) * sum_var_V) / norm(var_X);