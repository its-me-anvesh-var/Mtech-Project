#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#include<time.h>
#include<math.h>
#define PATTERNS    1599
#define FEATURES    11                        //// input layer nodes= FEATURES;
#define ROWS          4                          //// output layer nodes=rowsxcols;
#define COLS          2
#define TOTAL       (ROWS*COLS)
#define TRAIN_STEPS  170     //30
#define num_class    8
#define ETA          0.8
//#include "normalization.h"
char string1[25] = "wineqr";
int *tag,flag,**clusters,pos[TOTAL];
double  **input,**input1,**D,*DD,**similar;
int     *won;
double  *q_error;
int disp[num_class][num_class];
typedef struct{
    int           units;
    double        *output;
    double        **weights;
    double        **weightsave;

    }LAYER;
typedef struct{
     LAYER        *inputlayer;
     LAYER        *khonenlayer;
     int          *winpos;
     int          winner;
     double       eta;                            //eta=learing rate
     double       sigma;                          //sigma= size of topological neighborhood shirnks with itte....
     double       sigma_0;
     double       T1;                            ///timeconstant1(T1)
     double       Entropy;
     double       *mean;
     double        ***clusterpoints;
     double        **clusterpointmeans;
     double       beta_index;
     }SOM;

void initialization(SOM *Net)
{
int i,j,i1;
    Net->inputlayer=(LAYER *)   malloc(sizeof(LAYER));
    Net->khonenlayer=(LAYER *)  malloc(sizeof(LAYER));
    Net->inputlayer->units=FEATURES;
    Net->khonenlayer->units=TOTAL;
    Net->inputlayer->output=(double *)    malloc(sizeof(double)*FEATURES);
    Net->khonenlayer->weights=(double **) malloc(sizeof(double*)*TOTAL);
    Net->khonenlayer->weightsave=(double **) malloc(sizeof(double*)*TOTAL);
    Net->khonenlayer->output=(double *)   malloc(sizeof(double)*TOTAL);
     Net->clusterpoints=(double ***) malloc(sizeof(double**)*TOTAL);
    Net->clusterpointmeans=(double **) malloc(sizeof(double*)*TOTAL);
    for(i=0;i<TOTAL;i++){
       Net->khonenlayer->weights[i]=(double *)malloc(sizeof(double)*FEATURES);
       Net->khonenlayer->weightsave[i]=(double *)malloc(sizeof(double)*FEATURES);
       Net->winner;
       Net->Entropy;
       Net->beta_index;
       Net->clusterpoints[i]=(double **) malloc(sizeof(double*)*(PATTERNS));
       Net->clusterpointmeans[i]=(double *) malloc(sizeof(double)*(FEATURES));
       for(j=0;j<PATTERNS;j++){
        Net->clusterpoints[i][j]=(double *) malloc(sizeof(double)*(FEATURES+1));
       }
    }
    Net->mean=(double *)    malloc(sizeof(double)*FEATURES);


}
void initialization1()
{
  int i;
    tag=(int *)calloc(sizeof(int ),PATTERNS+1);
    q_error=(double *)calloc(sizeof(double ),TRAIN_STEPS+1);
    input=(double **)calloc(sizeof(double *),PATTERNS);
    input1=(double **)calloc(sizeof(double *),PATTERNS);
    D=(double **)calloc(sizeof(double *),TOTAL);
    similar=(double **)calloc(sizeof(double *),TOTAL);
    DD=(double *)calloc(sizeof(double ),TOTAL);
    for(i=0;i<PATTERNS;i++){
    input[i]=(double *)calloc(sizeof(double ),FEATURES+1);
    input1[i]=(double *)calloc(sizeof(double ),FEATURES+1);
    }
    for(i=0;i<TOTAL;i++){
    D[i]=(double *)calloc(sizeof(double ),TOTAL);
    similar[i]=(double *)calloc(sizeof(double ),TOTAL); }

}
/******************************************************************************
						RANDOM NUMBER GENERATION FROM DISTRIBUTIONS
 ******************************************************************************/
double random_real(double low,double high)
{
	return((double) rand()/RAND_MAX)*(high-low)+low;
}
void randomweights(SOM *Net)
{
int i,j;

  for(i=0;i<Net->khonenlayer->units;i++)
     {
     for(j=0;j<Net->inputlayer->units;j++)
        {
           Net->khonenlayer->weights[i][j]=random_real(-0.5,0.5);
           //printf("%lf\t",Net->khonenlayer->weights[i][j]);
        }
        //printf("\n");
     }
}
void readpatterns()
{
 int i,j;
 FILE *ifp,*fp;
 char ch[25];
 sprintf(ch, "%s.txt", string1);
 ifp=fopen(ch,"r");
 if(ifp==NULL)
	printf("File not found\n");
 for(i=0;i<PATTERNS;i++)
    {
      for(j=0;j<=FEATURES;j++)
	  fscanf(ifp,"%lf",&input[i][j]);

    }
 fclose(ifp);
// normalize(input1, PATTERNS, FEATURES,input);
 for(i=0;i<PATTERNS;i++)
 free(input1[i]);
 free(input1);
}

/*void readpatterns()
{
 int i,j;
 FILE *ifp,*fp;
 ifp=fopen("nmGDS4358data.txt","r");
 // ifp=fopen("membership_ALLAMLdata.txt","r");
 if(ifp==NULL)
	printf("File not found\n");
 for(i=0;i<PATTERNS;i++)
    {
      for(j=0;j<=FEATURES;j++)
	  fscanf(ifp,"%lf",&input[i][j]);

    }
 fclose(ifp);
 fp=fopen("nmGDS4358data.txt","r");
 if(fp==NULL)
	printf("File not found\n");
 for(i=0;i<PATTERNS;i++)
    {
      for(j=0;j<=FEATURES;j++)
	  fscanf(fp,"%lf",&input1[i][j]);

    }
 fclose(fp);

}*/
/**********************************************************
Sampling
************************************************************/
int randomindex()
{
 int p;
 while(1)
	 {
	  p=(int)((PATTERNS)*(rand()/(RAND_MAX + 1.0)));
	  if(tag[p]==1)
		 continue;
	  else
		 break;
	 }
	tag[p]=1;
 return(p);
}
void setinput(SOM *Net)
{
 int i;
 flag=randomindex();
 for(i=0;i<Net->inputlayer->units;i++)
    Net->inputlayer->output[i]=input[flag][i];

}
/***************************************************************
Similarity matching

******************************************************************/
void propagatenet(SOM *Net)
{
 int i,j;
  double out,weight,sum,minval;
   Net->winner=0;
  for(i=0;i<Net->khonenlayer->units;i++){
    sum=0.0;
    for(j=0;j<Net->inputlayer->units;j++){
        out=Net->inputlayer->output[j];
        weight=Net->khonenlayer->weights[i][j];
        sum+=(out-weight)*(out-weight);
    }
    Net->khonenlayer->output[i]=sqrt(sum);
    //printf("%lf\t",  Net->khonenlayer->output[i]);
  }
   //printf("\n\n");
  minval=Net->khonenlayer->output[0];
  for(i=0;i<Net->khonenlayer->units;i++)
  {
     if(Net->khonenlayer->output[i]<minval){
       minval=Net->khonenlayer->output[i];
       Net->winner=i;
      }
  }    //printf("avatharam-->%d\n",Net->winner);
   clusters[Net->winner][won[Net->winner]++]=flag;


}
/******************************************************************
Quantization Error
*******************************************************************/
double quantizationerror(SOM *Net)
{
int i,j;
double sum=0,out,weight,val=0.0;
    for(j=0;j<Net->inputlayer->units;j++){
       out=Net->inputlayer->output[j];
       weight=Net->khonenlayer->weights[Net->winner][j];
	   sum+=((out-weight)*(out-weight));
     }
     val=sqrt(sum);
     return(val);
}
void timeconstant1(SOM *Net)
{
 int x;
     x=(ROWS>COLS)?ROWS:COLS;
     Net->sigma_0=(double)x/0.8;
     printf("Net->sigma_0=%lf\n",Net->sigma_0);
     Net->T1=(double)(TRAIN_STEPS/log(Net->sigma_0));                        ///T2=TRAIN_STEPS
    printf("T1=%lf\n",Net->T1);
}
/********************************************************************
 Train the network
 ********************************************************************/
void trainkohonen(SOM *Net)
{
int i,j;
double lamda,out,weight,dist;
int    irow,icol,jrow,jcol;
   //printf("avatharam-->%d\n",Net->winner);
   jrow=Net->winner/COLS;                                             ///winning neuron two dimentional position
   jcol=Net->winner%COLS;
  for(i=0;i<Net->khonenlayer->units;i++)
   {
      irow=i/COLS;
      icol=i%COLS;
      dist=(pow((irow-jrow),2))+(pow((icol-jcol),2));
      lamda=exp(-pow((dist),2) / (2*pow(Net->sigma,2)));                 ////lambda=h(ij)
     // printf("%lf---%lf\n",dist,lamda);
     if(dist < pow(Net->sigma,2)){
         for(j=0;j<Net->inputlayer->units;j++){
   	       out=Net->inputlayer->output[j];
		   weight=Net->khonenlayer->weights[i][j];
		   Net->khonenlayer->weights[i][j]+=Net->eta*lamda*(out-weight);
          }
       }

   }
}
/******************************************************************************
								  SAVE AND UPDATE OF WEIGHTS
 ******************************************************************************/
void trainnet(SOM *Net)
{
int i,j,n=0,t,sum=0;
double lambda,errorval,error1;
timeconstant1(Net);
FILE *fp;
fp=fopen("randomerror.txt","w");
while(n<TRAIN_STEPS){
     error1=0;
     tag=(int *)calloc(sizeof(int ),PATTERNS+1);
     won=(int *)calloc(sizeof(int ),TOTAL);
     Net->winpos=(int *)  malloc(sizeof(int)*TOTAL);
     clusters=(int **)calloc(sizeof(int*),TOTAL);
     for(j=0;j<TOTAL;j++)
     clusters[j]=(int *)calloc(sizeof(int),PATTERNS);
     Net->eta=ETA*exp(-(double)n/TRAIN_STEPS);                    ///665599eta(t)=eta_0*exp(-(t/T2)) where t=itte(0,1,2...),T2=TRAIN_STEPS;
     //printf("eta=%lf\n",Net->eta);
	 Net->sigma=Net->sigma_0*exp(-(double)(n/Net->T1));		 	  /// sigma(t)=sigma_0*exp(-(t/T1)) where t=itte(0,1,2...), T1= T2/log(sigm_0);
	 //printf("sigma=%lf\n",Net->sigma);
     for(i=0;i<PATTERNS;i++){
     setinput(Net);
     propagatenet(Net);
     trainkohonen(Net);
     error1+=quantizationerror(Net);;
     }
     errorval=(double)error1/(double)PATTERNS;
     //if(n%100==0){
     fprintf(fp,"%d\t%lf\n",n,errorval);//}
    n+=1;


 }
 fclose(fp);
}
void sortarray(SOM *Net)
{
      int i,j,t,t1,sum=0;

  for(i=0;i<Net->khonenlayer->units;i++) {
     pos[i]=i;
     sum+=won[i];
     printf("%d--%d\t",i,won[i]);}
     printf("\n\n");
   for(i=0;i<Net->khonenlayer->units;i++){
       for(j=0;j<Net->khonenlayer->units;j++){
         if(won[i]>won[j])
          {
          t=won[i];
          won[i]=won[j];
          won[j]=t;
          t1=pos[i];
          pos[i]=pos[j];
          pos[j]=t1;
          }

       }
     }
      for(i=0;i<Net->khonenlayer->units;i++){
        printf("%d--%d\t",pos[i],won[i]); }
      /* for(i=0;i<TOTAL;i++){
        for(j=0;j<won[i];j++){
          printf("%d--%d--%d\t", i+1,j,clusters[pos[i]][j]);
        }printf("\n");
   }                   */
}

void betaindex(SOM* Net)
{
 int i,j,k,i1,j1,k1,i2,j2,k2,i3,j3,count=0,val;
 double sum,sum1,sum3,sum4,sum9,sum10;
 double sum5[TOTAL][PATTERNS],sum6[TOTAL][PATTERNS],sum7[TOTAL],sum8[TOTAL];
 double t1,t2;
FILE *fp;
 fp=fopen("output_cluters.txt","w");
   for(j=0;j<FEATURES;j++){ sum=0.0;
      for(i=0;i<PATTERNS;i++){
	    sum+=input[i][j];
      }
     Net->mean[j]=(double)sum/PATTERNS;
   }

  for(i=0;i<Net->khonenlayer->units;i++)
     { if(won[i]==0)
       break;
       count++;
    for(j=0;j<won[i];j++){
       val=clusters[pos[i]][j];
        Net->clusterpoints[i][j][FEATURES+1]=i+1;
      for(k=0;k<=FEATURES;k++){
        Net->clusterpoints[i][j][k]=input[val][k];
       fprintf(fp,"%lf\t",Net->clusterpoints[i][j][k]);
      }fprintf(fp,"%d\n",i+1);
    }//fprintf(fp,"\n");
  }
  fclose(fp);
 /***means*****/

    for(i1=0;i1<count;i1++){
       for(k1=0;k1<FEATURES;k1++){ sum1=0.0;
        for(j1=0;j1<won[i1];j1++){
           sum1+= Net->clusterpoints[i1][j1][k1];
        }
       Net->clusterpointmeans[i1][k1]=sum1/won[i1];
    }
  }
 count= num_class;
  /*******************************/
    for(i=0;i<count;i++){
      for(j=0;j<won[i];j++){
       sum5[i][j]=0;
       sum6[i][j]=0;
      }
     }
     /******************************/
      for(i2=0;i2<count;i2++){
      for(j2=0;j2<won[i2];j2++){
       sum3=0.0; sum4=0.0;
         for(k2=0;k2<FEATURES;k2++){
            sum3+=(Net->clusterpoints[i2][j2][k2]-Net->mean[k2])*(Net->clusterpoints[i2][j2][k2]-Net->mean[k2]);
            sum4+=(Net->clusterpoints[i2][j2][k2]-Net->clusterpointmeans[i2][k2])*(Net->clusterpoints[i2][j2][k2]-Net->clusterpointmeans[i2][k2]);
          }
           sum5[i2][j2]=sum3;
          // printf("sum5--%lf\t",sum5[i2][j2]);
           sum6[i2][j2]=sum4;
          // printf("sum6--%lf\t",sum6[i2][j2]);
        }
          printf("Avathar%d\n",i2);
      }//end i2
     // printf("Avathar\n");
  for(i3=0;i3<count;i3++){
       sum7[i3]=0.0;sum8[i3]=0.0;
       sum9=0,sum10=0;
     for(j3=0;j3<won[i3];j3++){
       sum9+=sum5[i3][j3];
       sum10+=sum6[i3][j3];
      }
      sum7[i3]=sum9;
      sum8[i3]=sum10;
      printf("cluster sum--%lf-%lf\n",sum7[i3],sum8[i3]);
    }
    t1=0.0;t2=0.0;
     for(i3=0;i3<count;i3++){
        t1+=sum7[i3];
        t2+=sum8[i3];
     }
    Net->beta_index=(double)t1/t2;
    printf("Net->beta_index=%lf",Net->beta_index);
}
void cluster_validity(SOM* Net)
{
    int i,j,i1,j1,i2,k,count=0,out1,count2[num_class],sum,sum1,sum2;
     int max,val,pos[num_class],pos1[num_class];
     FILE *fp1,*fp2;


      for(k=0;k<num_class;k++)
        {
         for(i=0;i<num_class;i++){ count2[i]=0.0;
            for(j=0;j<won[k];j++){
           out1=(int)Net->clusterpoints[k][j][FEATURES];
            if(out1==(i+1)){
             count2[i]++;
            }
          }
          disp[k][i]= count2[i];
       }

      }printf("\n\n");
       /*before confusionmatrix*/
      fp1= fopen("randomconfusionmatrix.txt","w");
      for(i=0;i<num_class;i++) {
         for(j=0;j<num_class;j++){
             printf("%d\t",disp[i][j]);
            fprintf(fp1,"%d\t",disp[i][j]);
         }fprintf(fp1,"\n\n");printf("\n\n");
      }fprintf(fp1,"\n\n");printf("\n\n");



    /****cluster points*/
     for(i=0;i<num_class;i++)
     pos[i]=0;pos1[i]=0;
     sum2=0;
     for(i=0;i<num_class;i++){
            val=0;
         if(pos[val]==-1)
         max=disp[i][val+1];
         else
         max=disp[i][val];
       for(j=0;j<num_class;j++){
           if(pos[j]==-1)
           continue;
         if(max<=disp[i][j]){
          max=disp[i][j];
          val=j;
         }
       }
        pos1[i]=val;
        pos[val]=-1;
        sum2+=disp[i][val];
        printf("%d--->%d\n",val+1,max);
        fprintf(fp1,"%d--->%d\n",val+1,max);
     }
     printf("\n\nTotal points correctly grouped-->%d\n\n",sum2);
     fprintf(fp1,"\n\nTotal points correctly grouped-->%d\n\n",sum2);
     /*after confusionmatrix*/
     for(i=0;i<num_class;i++){
       for(i1=0;i1<num_class;i1++){
        if(pos1[i1]==i){
         for(j=0;j<num_class;j++){
            printf("%d\t",disp[i1][j]);
            fprintf(fp1,"%d\t",disp[i1][j]);
         }fprintf(fp1,"\n\n");printf("\n\n");
        }
       }
      }
      fclose(fp1);
 //fp2= fopen("randomclass_cluters1.txt","w");
  for(i=0;i<num_class;i++)
     { if(won[i]==0)
       break;
    for(i1=0;i1<num_class;i1++){
      if(pos1[i1]==i){
          for(j1=0;j1<won[i1];j1++){
            for(k=0;k<FEATURES;k++){
             fprintf(fp2,"%lf\t", Net->clusterpoints[i1][j1][k]);
            }fprintf(fp2,"%d\n",i+1);
          }//fprintf(fp,"\n");
        } //end if
    }
  }
   for(i2=num_class;i2<Net->khonenlayer->units;i2++)//Net->khonenlayer->units
     { if(won[i2]==0)
       break;
          for(j1=0;j1<won[i2];j1++){
            for(k=0;k<FEATURES;k++){
             fprintf(fp2,"%lf\t", Net->clusterpoints[i2][j1][k]);
            }fprintf(fp2,"%d\n",i2+1);
          }//fprintf(fp,"\n");
  }
  fclose(fp2);
}
/****************************************
Main function
*******************************************/
int main()
{
 int i;
 SOM Net;
  double Time;
 clock_t start, end;
 start = clock();
 initialization1();
 initialization(&Net);
 randomweights(&Net);
 readpatterns();
 trainnet(&Net);
 sortarray(&Net);
 //winning_nodeweightssimilarity(&Net);
betaindex(&Net);
cluster_validity(&Net);
 end = clock();
    //printf("{clock(): S %10lu E %10lu milli secondsD %15.10f}\n", start,end,(end-start)/(double)( CLOCKS_PER_SEC/1000);
    Time = (((double)clock() - start) / CLOCKS_PER_SEC);
    printf("Time elapsed:%lf--%f\n", Time,(((double)clock() - start) / CLOCKS_PER_SEC));
    getch();
 return 1;

}
