#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#include<math.h>
#include<time.h>
//#define PATTERNS     103
//#define FEATURES     5565 
//#define num_class    6
#define f_e          1
#define f_d          5
/*******************************************************************************************
distance from center
*********************************************************************************************/
void dist_center(double **data, double *Z, int n_p, int n_f, int class)
{
   int i,j,k,k1,k2; 
   int l1=0,*count,*sum;
   double sum1,sum2,sum3,d,d1,d2,v;
   double **center, **variance;  
   center=(double**)malloc(class *sizeof(double*));      
   variance=(double**)malloc(class*(sizeof(double*)));
   count=(int *)calloc((class+1),sizeof(int));
   sum=(int *)malloc((class+1)*sizeof(int)); 
   for(k2=0;k2<class;k2++){
        center[k2]=(double *)calloc(n_f+1,sizeof(double));
        variance[k2]=(double*)calloc(n_f+1,sizeof(double));
        }
   //count[0]=0; 
    
    for(k=0;k<class;k++)
       {      sum[k]=0;           printf("k=%d\n",k);        
       for(i=0;i<n_p;i++)
           {
           if(data[i][n_f]==(double)k+1){//printf("\n%lf\n",data[i][n_f]);
              	sum[k]++;
                count[k+1]=i+1;}				
           }
          printf("\npoints =%d--%d\n",sum[k],count[k+1]); 
       } 
      for(k=0;k<class;k++)
      {printf("count=%d\n",k); 
 		 for(j=0;j<n_f;j++){  
            sum1=0; sum3=0;
          // printf("\n%d---%d \n ",count[k],count[k+1]);
             for(i=count[k];i<count[k+1];i++)
		         {                                             
                 sum1+=data[i][j];
                 }
             center[k][j]=sum1/(double)sum[k];   
   		  // printf("center=%lf ",l->center[k][j]);          
   		   for(i=count[k];i<count[k+1];i++){                
              sum3+=(data[i][j]-center[k][j])*(data[i][j]- center[k][j]);
             }
              variance[k][j]=sqrt(sum3/(double)sum[k]);    //////////standarddevation=varince
             //printf("center=%lf ",l->variance[k][j]);            
          }                                         
       //   printf("\n");
       }  
      for(k=0;k<class;k++){
          for(i=count[k];i<count[k+1];i++){                            
                d=0.0; sum2=0;  
              for(j=0;j<n_f;j++){
                 d=(data[i][j]-center[k][j])/(0.000001+variance[k][j]);
                 sum2+=d*d;
               }
             Z[l1++]=sqrt(sum2); 
             //printf("center=%lf ",l->Z[i][k]); 
        }       
	//	printf("\n");	
   }           
    for(k=0;k<class;k++){ 
      free(center[k]);
      free(variance[k]);
      }
      free(center);
      free(variance);
      free(count);
      free(sum);
}     
/*****************************************************************
finding membership of each pattern
********************************************************************/
void pattern_membership(double *Z,double *F,int n_p)
{
int i,j,k,l1;
double d1,d2,d3,d4,sum4;
        
	  for(i=0;i<n_p;i++){                               
            d1=Z[i]/(double)f_d;   
    	    d2=pow(d1,f_e);
            d3=1+d2;
            d4=(double)1/d3;
            F[i]=d4;  
            //printf("%d---%f\t",i,F[i]);
      }                  
}

