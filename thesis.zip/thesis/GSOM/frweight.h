#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#include<math.h>
#include<time.h>

//#define PATTERNS   103
////#define FEATURES   5565
#define C_AS       FEATURES
//#define num_class  6
//#define new_clusters 6
#define f_e          1
#define f_d          5
double *d_attributes; 
typedef struct{
      double  *a_values;                               ////a_values=attributevalues
      double  **s_matrix;                               ////s_matrix=similarity matrix
      double  **low_approxi1;                           //// decision attribute lower approximations                     
      double   *A_DEG1,A_DEPDEG1,*A_DEG2,A_DEPDEG2;
       }Attribute;                                      
typedef struct{
        Attribute       **c_attributes;                 ////c_values=conditional attributevalues                           
        Attribute       *decisioncol;                   ////decisioncol=decision attributevalues         
             int   *flag;
        }Rough;
/*void intialization(Rough *R)
{
    int i,j,k;
     R->c_attributes=(Attribute **)malloc(C_AS+1*sizeof(Attribute*));
     R->decisioncol=(Attribute *)malloc(sizeof(Attribute));
     R->decisioncol->low_approxi1=(double **)calloc(num_class+1,sizeof(double*));
     for(i=0;i<C_AS;i++){
        R->c_attributes[i]=(Attribute *)malloc(PATTERNS*sizeof(Attribute ));  
        R->c_attributes[i]->a_values=(double *)calloc(PATTERNS+1,sizeof(double));    
     }
     for(k=0;k<num_class;k++){               
            R->decisioncol->low_approxi1[k]=(double *)calloc(PATTERNS+1,sizeof(double));       
         } 
     d_attributes=(double *)calloc(PATTERNS+1,sizeof(double));
     printf("initialization  avatharam\n"); 
}
*/
/***********************************************
equivalance matrix
***********************************************/
void equivalance_compute(Attribute *c)//,FILE *fp
{   
int i,j,k;
int *count1;
double l1,l2,l3,l4,l5,l6;  
double *x1,*x2,*x4,*center,*variance,sum1,sum3;
count1=(int *)malloc((num_class+1)*sizeof(int));
x1=(double *)calloc(PATTERNS+1,sizeof(double ));
x2=(double *)calloc(PATTERNS+1,sizeof(double ));
x4=(double *)calloc(PATTERNS+1,sizeof(double ));
center=(double *)calloc(PATTERNS+1,sizeof(double ));
variance=(double *)calloc(PATTERNS+1,sizeof(double ));
     for(i=0;i<PATTERNS;i++){
        x4[i]=c->a_values[i];
        x1[i]=c->a_values[i];
        x2[i]=c->a_values[i];
       }
 //****************mean varaince of each class*********//////

for(k=1;k<=num_class;k++){
   count1[k-1]=0.0;sum1=0.0;sum3=0.0; 
   for(i=0;i<PATTERNS;i++){        
      if(d_attributes[i]==(double)k){ 
        count1[k-1]++;                                              
        sum1+=x4[i];    
      }   
   }
   center[k-1]=(sum1/(count1[k-1]));  
  // printf ("center=%lf",c->center[k-1]);     		              
   for(i=0;i<PATTERNS;i++){                      
       if(d_attributes[i]==(double)k){                 
         sum3+=(x4[i]-center[k-1])*(x4[i]-center[k-1]);
       }
   }
   variance[k-1]=(sum3/(count1[k-1]));    //////////standarddevation=varince
  // printf("variance=%lf",c->variance[k-1]);                             
} 
 /******************************variace*****************/      
             
for(i=0;i<PATTERNS;i++){                     
   for(k=1;k<=num_class;k++){                                                              
      for(j=0;j<PATTERNS;j++){   
       l1=0,l2=0,l3=0,l4=0,l5=0;    
       if(d_attributes[j]==(double)k){       
        l1=x2[j]-x1[i]+(1+variance[k-1]);
        l2=l1/(1+variance[k-1]);
        l3=x1[i]-x2[j]+(1+variance[k-1]);
        l4=l3/(1+variance[k-1]);    
        l5=(l2<l4)?l2:l4;    
        c->s_matrix[i][j]=(l5<0)?0:l5;
     // printf("%f\t", c->s_matrix[i][j]);
     //  fprintf(fp,"%f\t", c->s_matrix[i][j]);        
       }///end if//
       ///end for j 
      }
    } //end for k
    //fprintf(fp,"\n");
}
free(x1);
free(x2);
free(x4);
free(count1);
free(center);
free(variance);
}
/***************************************************************************
Finding lower and upper approximation of an attribute
***************************************************************************/
void lower_approximation(Attribute *c1, Attribute *c2,double *d1,int r)//(double **D,double **l,double *d1,double **M,double *v,int r)
{
int k,i,j,j1,j2,i1;
int  *count,*count1,*points;
double x1,x2,l1,l2,impl1,impl2,prod; 
double min,min1,sum,sum2=0;
double *matrix,*matrix1,**MAX;
count=(int *)calloc(r,sizeof(int ));
count1=(int *)calloc(r,sizeof(int ));
points=(int *)calloc(num_class,sizeof(int ));
matrix =(double *)calloc(r,sizeof(double ));
matrix1 =(double *)calloc(r,sizeof(double ));
MAX=(double **)calloc(num_class+1,sizeof(double*));
for(i=0;i<num_class;i++)
MAX[i]=(double *)calloc(r+1,sizeof(double)); 

   for(k=1;k<=num_class;k++){
      points[k-1]=0.0; sum=0.0;
      for(i=0;i<r;i++){ 
         count[i]=0.0; count1[i]=0;min =0;min1=0;	
      for(j=0;j<r;j++){   
        if(d1[j]<(k)||d1[j]>(k)){                                                                      
           x1=c1->s_matrix[i][j];
           x2=c2->low_approxi1[k-1][j];  
          //printf("\nx1=%f--x2=%f",x1,x2); 
           matrix1[count1[i]] = (1-x1)>x2?(1-x1):x2;//?x1:x2; 
          // printf("%f  ",matrix1[count1[i]]);
           count1[i]++;
         
           }// end if j       
        else{              
           x1=0,x2=0,l1=0;        
		   x1=c1->s_matrix[i][j];
           x2=c2->low_approxi1[k-1][j];
           //printf("\nx1=%f--x2=%f",x1,x2); 
           matrix[count[i]]=x1*x2;
           //printf("%f\t  ",matrix[count[i]]);
           count[i]++; 
         }
      }//end for j
         min=matrix1[0];
         for(j2=0;j2<count1[i];j2++){
            if(min>matrix1[j2]){
            min=matrix1[j2];}
           }  
        //  printf("min=%f  ",min); 
         min1= matrix[0];    
         for(i1=0;i1<count[i];i1++){
            if(min1>matrix[i1]){
            min1=matrix[i1];}
         }
       //printf("min1=%f\n",min1); 
       if (d1[i]== k){
          MAX[k-1][points[k-1]]=min1<min?min1:min;   
      //  printf("\nclass-%d   %d=%lf\t",k,points[k-1],MAX[k-1][points[k-1]]);    
       points[k-1]++;
     } //end if
    }//end fot i   
    for(j=1;j<=points[k-1];j++){          
        sum+=MAX[k-1][j];
     }            
     c1->A_DEG1[k-1]=sum/points[k-1];
     sum2+=sum;      
    //printf("lower%d=%lf\t",k,c1->A_DEG1[k-1]);          
   }   ///end for k    
   c1->A_DEPDEG1=sum2/PATTERNS;
   free(count);
   free(count1);
   free(matrix);
   free(matrix1);
   free(points);  
   for(i=0;i<num_class;i++)
     free(MAX[i]);   
     free(MAX);      
}
/***************************************************************************
Finding upper approximation of an attribute
***************************************************************************/
void upper_approximation(Attribute *c1, Attribute *c2,double *d1,int r) //(double *d,double **D,double **l,double *d1,double *v,int r)//(Attribute *c1, Attribute *c2,double *d1,int r)//
{
int k,i,j,j1,j2,i1;
int  *count,*count1,*points,c=0;
double x1,x2,l1,l2,impl1,impl2,prod; 
double min,min1,sum,sum2=0;
double *matrix,*matrix1,**MAX;
count=(int *)calloc(r,sizeof(int ));
count1=(int *)calloc(r,sizeof(int ));
points=(int *)calloc(num_class,sizeof(int ));
matrix =(double *)calloc(r,sizeof(double ));
matrix1 =(double *)calloc(r,sizeof(double ));
MAX=(double **)calloc(num_class+1,sizeof(double*));
for(i=0;i<num_class+1;i++)
MAX[i]=(double *)calloc(r+1,sizeof(double)); 

   for(k=1;k<=num_class;k++){
      points[k-1]=0.0; sum=0.0;
      for(i=0;i<r;i++){ 
         count[i]=0.0; count1[i]=0;min =0;min1=0;	
      for(j=0;j<r;j++){   
        if(d1[j]<(k)||d1[j]>(k)){     //printf("\nx1=%f",d1[j]);                                                                 
           x1=c1->s_matrix[i][j];//x1=D[i][j];
           x2=c2->low_approxi1[k-1][j]; //  x2=l[k-1][j];  
          //printf("\nx1=%f--x2=%f",x1,x2); 
           matrix1[count1[i]] = x1<x2?x1:x2;//?x1:x2; 
          // printf("%f  ",matrix1[count1[i]]);
           count1[i]++;         
           }// end if j       
        else{              
           x1=0,x2=0,l1=0;        
		   x1=c1->s_matrix[i][j];
           x2=c2->low_approxi1[k-1][j];
           matrix[count[i]]=(1-x1+x1*x2);
           //printf("%f\t  ",matrix[count[i]]);
           count[i]++; 
         }
      }//end for j
         min=matrix1[0];
         for(j2=0;j2<count1[i];j2++){
            if(min<matrix1[j2]){
            min=matrix1[j2];}
           }  
        //  printf("min=%f  ",min); 
         min1= matrix[0];    
         for(i1=0;i1<count[i];i1++){
            if(min1<matrix[i1]){
            min1=matrix[i1];}
         }
       // printf("min1=%f\n",min1); 
       if (d1[i]== k){
          MAX[k-1][points[k-1]]=min1>min?min1:min;   
      //  printf("\nclass-%d   %d=%lf\t",k,points[k-1],MAX[k-1][points[k-1]]);    
       points[k-1]++;
     } //end if
    }//end fot i   
    for(j=1;j<=points[k-1];j++){          
        sum+=MAX[k-1][j];
     }            
    // v[k-1]=sum;
     c1->A_DEG2[k-1]=sum/points[k-1];
    sum2+=sum;      
    //printf("upper%d=%lf\t",k,c1->A_DEG2[k-1]);         
   }   ///end for k   
    
   c1->A_DEPDEG2=sum2/PATTERNS; 
   free(count);
   free(count1);
   free(matrix);
   free(matrix1);
   free(points); 
   for(i=0;i<num_class;i++)
     free(MAX[i]);   
     free(MAX);      
}

/*************************************************/
          /*Calling Functions */
/*************************************************/
/*void allocate_data(Rough *R,double **data)
{
     
     int i,j,k;       printf("%d\n",C_AS);   
     for(j=0;j<C_AS;j++){                       
         for(i=0;i<PATTERNS;i++){  
           R->c_attributes[j]->a_values[i]=data[i][j];   
         //  printf("avatharam_%lf\n", R->c_attributes[j]->a_values[i]);      
         }// printf("\n");  
     }   
     for(i=0;i<PATTERNS;i++){   
         d_attributes[i]=data[i][C_AS];     
            
      } // printf("avatharam\n");     
}
void decision_classes(Rough *R, double *desired)
{
   int i,j,k,k1;
       for(k=0;k<num_class;k++){
       for(i=0;i<PATTERNS;i++){     
         if(d_attributes[i]<(k+1)||d_attributes[i]>(k+1)){         
          R->decisioncol->low_approxi1[k][i]=1.0;
         // printf("%lf\t", R->decisioncol->low_approxi1[k][i]);
          }
          else{	
		  R->decisioncol->low_approxi1[k][i]=desired[i];
         // printf("%lf\t", R->decisioncol->low_approxi1[k][i]);
          }    
       }
    }             
}*/
void Lower_matrix(Rough *R, double **data, double *desired, double **lowervalues, double **uppervalues)//FILE *fp
{ 
   int i,j,k,j1,k1;
     R->c_attributes=(Attribute **)malloc(C_AS*sizeof(Attribute*));
     R->decisioncol=(Attribute *)malloc(sizeof(Attribute));
     R->decisioncol->low_approxi1=(double **)calloc(num_class+1,sizeof(double*));
     for(i=0;i<C_AS;i++){
        R->c_attributes[i]=(Attribute *)malloc(PATTERNS*sizeof(Attribute ));  
        R->c_attributes[i]->a_values=(double *)calloc(PATTERNS+1,sizeof(double));    
     } 
     d_attributes=(double *)calloc(PATTERNS+1,sizeof(double)); 
     for(k=0;k<num_class;k++){               
            R->decisioncol->low_approxi1[k]=(double *)calloc(PATTERNS+1,sizeof(double));       
         }
     /**************data assign**************/
     for(j=0;j<C_AS;j++){                       
         for(i=0;i<PATTERNS;i++)
           R->c_attributes[j]->a_values[i]=data[i][j];
      }
      for(i=0;i<PATTERNS;i++){   
         d_attributes[i]=data[i][C_AS];                 
      } 
      /**************decision values assign********/     
     for(k=0;k<num_class;k++){
       for(i=0;i<PATTERNS;i++){     
         if(d_attributes[i]<(k+1)||d_attributes[i]>(k+1)){         
          R->decisioncol->low_approxi1[k][i]=1.0;
         // printf("%lf\t", R->decisioncol->low_approxi1[k][i]);
          }
          else{	
		  R->decisioncol->low_approxi1[k][i]=desired[i];
         // printf("%lf\t", R->decisioncol->low_approxi1[k][i]);
          }    
       }
     }       
     /**************Find lower and upper values********************/
     
   for(j=0;j<C_AS;j++){//printf("j-->%d",j);
      R->c_attributes[j]->s_matrix=(double **)calloc(PATTERNS+1,sizeof(double*));   
      for(i=0;i<PATTERNS;i++){ 
        R->c_attributes[j]->s_matrix[i]=(double *)calloc(PATTERNS+1,sizeof(double));        
       }   
       R->c_attributes[j]->A_DEG1=(double *)calloc(num_class+1,sizeof(double));
       R->c_attributes[j]->A_DEPDEG1; 
       R->c_attributes[j]->A_DEG2=(double *)calloc(num_class+1,sizeof(double));
       R->c_attributes[j]->A_DEPDEG2; 
       equivalance_compute(R->c_attributes[j]);
       lower_approximation(R->c_attributes[j],R->decisioncol,d_attributes,PATTERNS); 
       upper_approximation(R->c_attributes[j],R->decisioncol,d_attributes,PATTERNS);    
      for(k=0;k<num_class;k++){
       lowervalues[k][j]=R->c_attributes[j]->A_DEG1[k];  
       //printf("%lf\t",  lowervalues[k][j]);
       uppervalues[k][j]=R->c_attributes[j]->A_DEG2[k];  
       //printf("%lf\t",  uppervalues[k][j]); 
        } 
       for(i=0;i<PATTERNS;i++){
       free(R->c_attributes[j]->s_matrix[i]);}
       free(R->c_attributes[j]->s_matrix);           
       free(R->c_attributes[j]->A_DEG1);    
       free(R->c_attributes[j]->A_DEG2);   
     }  
     /****************Delelte meomry******/
     for(j1=0;j1<C_AS;j1++)
     free(R->c_attributes[j1]);
    free(R->c_attributes); 
      for(k1=0;k1<num_class;k1++)               
     free(R->decisioncol->low_approxi1[k1]);     
     free(R->decisioncol->low_approxi1);    
     free(R->decisioncol);
     free(d_attributes);    printf("avatharam\n");/**/     
}























